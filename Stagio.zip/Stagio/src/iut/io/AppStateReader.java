package iut.io;
/**
 * <p>
 * Nom de l'application : STAGIO gestionnaire de stage
 * </p>
 * <p>
 * Description : gestionnaire de stage
 * </p>
 * 
 * @author Johnathan, Joe, Pierre et Thibault
 * @version 1.0
 */
import java.io.File;
import java.io.IOException;

import iut.app.ApplicationSession;

public class AppStateReader {
	public AppStateReader() {
		
	}

	public void load(File file) throws IOException {
		// TODO Auto-generated method stub
     //   ApplicationSession.instance().setAgenda1(XMLProjectReader.load(file));
	}
}
